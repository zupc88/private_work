package bookrental;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface BuyRepository extends PagingAndSortingRepository<Buy, Long>{


}